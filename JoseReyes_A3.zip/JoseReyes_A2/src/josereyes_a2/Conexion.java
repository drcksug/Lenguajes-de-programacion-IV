/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package josereyes_a2;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Reygon
 */
public class Conexion {
    public Connection getConnection(){
        Connection con = null;
        String base = "bancomexicano";
        String url = "jdbc:mysql://localhost:3306/" + base;
        String user = "root";
        String pasword = "";
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(url, user, pasword);
            //JOptionPane.showMessageDialog(null, "Conexión Exitosa");
        } catch (Exception e) {
            System.err.println(e);
        }
        return con;
    }
}
